const dati = document.querySelector('.dati');
const dadi = document.querySelector('.dadi')
const img_pc = document.getElementById('imgPc')
const img_pl = document.getElementById('imgPl')
const vinto = document.querySelector('.vinto')
const perso = document.querySelector('.perso')

let turnig = 0; 
let ppc = 0; 
let ppl = 0; 

function start(){
    dati.classList.add('hidden')
    dadi.classList.remove('hidden')
    const turni = document.getElementById('turni')
    const name = document.getElementById('nome')
}

function gioca(){
    const turni = document.getElementById('turni');
    if(turnig < turni.value){
        turnig++;

        let scelta_pc = Math.round(Math.random()*5+1);
        let scelta_pl = Math.round(Math.random()*5+1);
        console.log(scelta_pc);
        console.log(scelta_pl);

        img_pc.src="img/" + scelta_pc + ".png";
        img_pl.src="img/" + scelta_pl + ".png";

        if(scelta_pc>scelta_pl){
            ppc++; 
        }else if(scelta_pl>scelta_pc){
            ppl++; 
        }
    } else {
        if(ppc>ppl){
            dadi.classList.add('hidden')
            perso.classList.remove('hidden')
        }else{
            dadi.classList.add('hidden')
            vinto.classList.remove('hidden')
        }
        finegioco(); 
    }
}


function finegioco(){
    dadi.classList.add('hidden');
}

function reset(){
    location.reload();
}